import asyncio, os
from dotenv import load_dotenv
load_dotenv("/app/backend/.env")
from emergentintegrations.llm.chat import LlmChat, UserMessage
async def one(m):
    try:
        c=LlmChat(api_key=os.environ["GEMINI_API_KEY"],session_id="p",system_message="hi").with_model("gemini",m)
        r=await c.send_message(UserMessage(text="Say OK")); return m,"OK",r[:20]
    except Exception as e:
        s=str(e); i=s.find('"message"'); return m,"ERR",s[i:i+400]
async def main():
    for m in ["gemini-3-flash-preview","gemini-3.5-flash","gemini-3.6-flash","gemini-3.7-flash","gemini-3.8-flash","gemini-3.1-pro-preview"]:
        print(*(await one(m)))
asyncio.run(main())
